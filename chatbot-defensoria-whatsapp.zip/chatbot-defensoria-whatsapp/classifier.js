// classifier.js
//
// Implementa el "Servicio de Clasificacion IA" de la arquitectura (Practica 5).
// Responsabilidad (RF05): dado el texto del relato, devolver si es
// clasificado como verdadero, con que confianza, y el perfil emocional.
//
// ESTADO ACTUAL: este archivo trae un clasificador de respaldo (heuristico,
// NO el modelo real) para que el bot funcione de inmediato sin depender de
// un servidor de IA ya desplegado. Cuando el modelo DeBERTa/mDeBERTa-v3
// (evaluado y afinado segun la Practica 3) este corriendo como servicio
// propio -- por ejemplo un microservicio Python con FastAPI que exponga
// POST /api/v1/clasificar, como quedo documentado en la Practica 5 --
// basta con definir la variable de entorno CLASSIFIER_API_URL para que
// este modulo llame a ese endpoint en vez de usar el heuristico.
//
// Contrato esperado del endpoint real (ver Practica 5, seccion de API):
//   POST {CLASSIFIER_API_URL}
//   Body:  { "texto": string }
//   Resp:  { "esVerdadero": boolean, "confianza": number (0-1),
//            "perfilEmocional": string[], "estilo": "emocional"|"logico" }

const UMBRAL_VERACIDAD = 0.5;

const PALABRAS_EMOCION_MIEDO = ["miedo", "asustad", "terror", "amenaz"];
const PALABRAS_EMOCION_TRISTEZA = ["triste", "llor", "deprimid", "solo", "sola"];
const PALABRAS_EMOCION_TRAUMA = ["trauma", "no puedo dormir", "pesadilla", "revivo"];
const PALABRAS_ESTILO_LOGICO = ["fecha", "hora", "lugar", "testigo", "evidencia"];

function clasificadorHeuristico(texto) {
  const t = texto.toLowerCase();

  // Heuristica MUY simple de respaldo: parte de una confianza baja y solo
  // la sube si hay suficiente detalle; mensajes cortos o de puro ruido
  // ("jajaja", "xd", saludos) deben quedar por debajo del umbral.
  const palabras = t.split(/\s+/).filter(Boolean);
  let confianza = 0.3;
  if (palabras.length >= 10) confianza += 0.15;
  if (palabras.length >= 25) confianza += 0.15;
  if (palabras.length >= 50) confianza += 0.1;
  if (/(.)\1{2,}/.test(t)) confianza -= 0.15; // "jajaja", "xxxxx", risas repetidas
  if (/\b(ja){2,}\b|\bxd+\b|\blol\b/.test(t)) confianza -= 0.2; // ruido tipico de chat
  confianza = Math.max(0, Math.min(1, confianza));

  const perfilEmocional = [];
  if (PALABRAS_EMOCION_MIEDO.some((p) => t.includes(p))) perfilEmocional.push("miedo");
  if (PALABRAS_EMOCION_TRISTEZA.some((p) => t.includes(p))) perfilEmocional.push("tristeza");
  if (PALABRAS_EMOCION_TRAUMA.some((p) => t.includes(p))) perfilEmocional.push("trauma");

  const estilo = PALABRAS_ESTILO_LOGICO.some((p) => t.includes(p)) ? "logico" : "emocional";

  return {
    esVerdadero: confianza >= UMBRAL_VERACIDAD,
    confianza: Number(confianza.toFixed(2)),
    perfilEmocional,
    estilo,
  };
}

async function clasificarConServicioReal(texto) {
  const url = process.env.CLASSIFIER_API_URL;
  const resp = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ texto }),
  });
  if (!resp.ok) {
    throw new Error(`Servicio de clasificacion respondio ${resp.status}`);
  }
  return resp.json();
}

async function clasificar(texto) {
  if (process.env.CLASSIFIER_API_URL) {
    try {
      return await clasificarConServicioReal(texto);
    } catch (err) {
      console.error("[classifier] Fallo el servicio real, usando heuristico de respaldo:", err.message);
      return clasificadorHeuristico(texto);
    }
  }
  return clasificadorHeuristico(texto);
}

module.exports = { clasificar, UMBRAL_VERACIDAD };
