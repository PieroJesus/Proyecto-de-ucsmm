# Chatbot de la Defensoría Universitaria (WhatsApp)

Prototipo funcional del chatbot conversacional con IA para dar a conocer la
Defensoría Universitaria de la UCSM y recibir denuncias anónimas de acoso,
ahora sobre **WhatsApp** en vez de Telegram.

## Qué tecnología usa y por qué

Se usa [`whatsapp-web.js`](https://wwebjs.dev/), una librería que controla una
cuenta normal de WhatsApp (no WhatsApp Business API) automatizando WhatsApp
Web por detrás. Se eligió porque **no requiere aprobación de Meta ni un
número de empresa verificado** — perfecto para un prototipo de tesis. La
limitación real: es una librería no oficial, así que no debe usarse para un
volumen muy alto de mensajes ni como solución 100% estable a largo plazo
(para producción real, el equivalente oficial sería la WhatsApp Business
Platform / Cloud API de Meta).

## Instalación

```bash
npm install
```

(La primera vez, `whatsapp-web.js` descarga una copia de Chromium — por eso
necesita conexión a internet normal; en este chat de Claude no se pudo
descargar porque el entorno de pruebas tiene la red restringida, pero en tu
computadora funcionará sin problema).

## Ejecutar el bot

```bash
node index.js
```

Va a aparecer un **código QR en la terminal**. Ábre WhatsApp en tu celular →
**Ajustes → Dispositivos vinculados → Vincular un dispositivo**, y escanéalo.
Desde ese momento, el número de WhatsApp que usaste queda actuando como el
bot: cualquier persona que le escriba a ese número recibirá las respuestas
automáticas.

## Qué entiende el bot (sin menús, todo en texto libre)

| El usuario escribe | El bot hace |
|---|---|
| `hola` | Mensaje de bienvenida (RF01) |
| `¿qué es la Defensoría Universitaria?` | Información institucional (RF02) |
| `denunciar` | Pide consentimiento (RF10) y luego inicia el relato libre (RF03, RF04) |
| *(el relato, en uno o varios mensajes)* | Se va guardando en memoria, sin responder a cada mensaje |
| `listo` | Clasifica el relato con IA (RF05) y, si es verdadero, lo guarda con un ID anónimo (RF06, RF07, RF11) |
| `estado DEF-XXXXXXXX` | Consulta el seguimiento de un caso (RF09) |

## Conectar los 3 modelos de IA reales (carpeta `ia_service/`)

Sin un servicio de IA conectado, `classifier.js` usa un **heurístico simple
de respaldo** (cuenta palabras y detecta ruido tipo "jajaja"), para que el
bot funcione de inmediato.

En la carpeta `ia_service/` ya está el microservicio real que combina los
**3 modelos comparados en la tesis** (TF-IDF+SVM, RoBERTa y mDeBERTa-v3,
usados como extractores de embeddings con un clasificador encima, de forma
que los 3 tienen Accuracy/F1 reales) — lee `ia_service/README.md` para
instalarlo, entrenarlo y correrlo (necesita internet normal para descargar
los modelos de Hugging Face; no corre dentro del sandbox de Claude).

Resumen rápido:
```bash
cd ia_service
pip install -r requirements.txt
python entrenar_modelos.py      # entrena y evalua los 3 modelos (una vez)
uvicorn ia_service:app --host 0.0.0.0 --port 8000
```

Cuando lo tengas corriendo, solo agrega esta variable de entorno antes de
arrancar el bot:

```bash
CLASSIFIER_API_URL=http://localhost:8000/api/v1/clasificar node index.js
```

Si ese servicio falla o no responde, el bot cae automáticamente de vuelta al
heurístico de respaldo (no se cae todo el bot).

## Dónde se guardan los datos (por ahora)

`storage.js` simula, con archivos JSON locales dentro de `data/` (se crean
solos al primer uso, no están en el repositorio), los dos componentes de la
arquitectura que en producción real serían externos:

- `data/consents.json` — qué números de WhatsApp (guardados **solo como
  hash**, nunca en texto plano) ya dieron su consentimiento (RF10).
- `data/defensoria_db.json` — simula la base de datos real de la Defensoría
  Universitaria. En producción, `guardarEnDefensoria()` y `consultarEstado()`
  en `storage.js` deben reemplazarse por llamadas a la API que la OTI
  habilite sobre su base de datos real (como quedó definido en la Práctica
  5, "Adaptador de Base de Datos de la Defensoría").
- `data/revision_manual.json` — casos que no superaron el umbral de
  veracidad tras un reintento, y quedan para revisión manual.

**Ningún archivo guarda el número de WhatsApp junto con el contenido de una
denuncia** — eso es intencional, para cumplir el principio de anonimización
(RNF01).

## Siguientes pasos sugeridos

1. Probar el flujo completo escaneando el QR con un número de prueba.
2. Desplegar el bot en un servicio gratuito tipo Render o Railway (como se
   definió en la Práctica 5) para que quede corriendo 24/7 sin depender de
   tu computadora.
3. Entrenar/exportar el modelo DeBERTa como servicio HTTP y conectar
   `CLASSIFIER_API_URL`.
4. Coordinar con la OTI el acceso real a la base de datos de la Defensoría
   para reemplazar los archivos JSON locales.
