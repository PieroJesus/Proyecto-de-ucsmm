# ia_service.py
#
# Microservicio de clasificacion (el "Servicio de Clasificacion IA" de la
# arquitectura, Practica 5), usando los 3 modelos de la tesis con la
# Opcion 2 (embeddings congelados + clasificador chico encima):
#
#   Modelo A - TF-IDF + SVM
#     Entrenamiento supervisado clasico sobre el texto crudo.
#
#   Modelo B - RoBERTa (xlm-roberta-base) + Regresion Logistica
#     RoBERTa NO se reentrena (esta "congelado"): solo convierte cada
#     relato en un vector numerico (embedding). Encima de esos vectores
#     se entrena una Regresion Logistica con el dataset semilla. Esto
#     SI produce Accuracy/F1 reales y comparables con los otros modelos.
#
#   Modelo C - mDeBERTa-v3 (microsoft/mdeberta-v3-base) + Regresion Logistica
#     Igual que el modelo B, pero usando mDeBERTa-v3 (la misma familia
#     que reporto la tesis como la de mejor desempeno) como extractor
#     de embeddings.
#
# IMPORTANTE: estos 3 modelos deben entrenarse primero corriendo
#   python entrenar_modelos.py
# (una sola vez; guarda los modelos y sus metricas en modelos_entrenados/).
# Si ese paso no se corrio todavia, este servicio lo avisa claramente al
# arrancar en vez de fallar de forma confusa.
#
# El perfil emocional (28 categorias) y el estilo narrativo SI se calculan
# con zero-shot (mDeBERTa-v3 ya afinado para NLI por terceros), porque no
# existe un dataset de emociones etiquetado para entrenar eso de forma
# supervisada -- igual que describe la tesis para esa parte especifica.
#
# Instalar:   pip install -r requirements.txt
# Entrenar:   python entrenar_modelos.py
# Correr:     uvicorn ia_service:app --host 0.0.0.0 --port 8000

import json
import logging
import os
import pickle
from typing import List

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from embeddings import obtener_embeddings, MODELO_B_ROBERTA, MODELO_C_MDEBERTA

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("ia_service")

app = FastAPI(title="Servicio de Clasificacion IA - Defensoria Universitaria UCSM")

CARPETA_MODELOS = "modelos_entrenados"
UMBRAL_VERACIDAD = 0.5
UMBRAL_EMOCION = 0.55

HIPOTESIS_ESTILO_EMOCIONAL = "Este mensaje está escrito de forma emocional."
HIPOTESIS_ESTILO_LOGICO = "Este mensaje está escrito de forma objetiva y descriptiva de hechos."

CATEGORIAS_EMOCIONALES = [
    "miedo", "tristeza", "ira", "verguenza", "culpa", "ansiedad", "impotencia",
    "desconfianza", "confusion", "soledad", "angustia", "frustracion",
    "humillacion", "inseguridad", "nerviosismo", "tension", "desesperanza",
    "alivio", "esperanza", "calma", "indignacion", "preocupacion", "aislamiento",
    "trauma", "rencor", "resignacion", "alerta", "agobio",
]  # 28 categorias, igual al numero declarado en la tesis


class SolicitudClasificacion(BaseModel):
    texto: str


class RespuestaClasificacion(BaseModel):
    esVerdadero: bool
    confianza: float
    perfilEmocional: List[str]
    estilo: str
    detalleModelos: dict


# ---------------------------------------------------------------------
# Carga de los 3 modelos ya entrenados (ver entrenar_modelos.py)
# ---------------------------------------------------------------------
_modelo_a = None
_modelo_b = None
_modelo_c = None
_metricas = None
_pipeline_emocion = None


def _cargar_modelos_entrenados():
    global _modelo_a, _modelo_b, _modelo_c, _metricas
    if _modelo_a is not None:
        return

    ruta_a = os.path.join(CARPETA_MODELOS, "modelo_a.pkl")
    ruta_b = os.path.join(CARPETA_MODELOS, "modelo_b.pkl")
    ruta_c = os.path.join(CARPETA_MODELOS, "modelo_c.pkl")
    ruta_metricas = os.path.join(CARPETA_MODELOS, "metricas.json")

    if not (os.path.exists(ruta_a) and os.path.exists(ruta_b) and os.path.exists(ruta_c)):
        raise RuntimeError(
            "Los modelos todavia no estan entrenados. Corre primero:\n"
            "    python entrenar_modelos.py\n"
            "y vuelve a arrancar este servicio."
        )

    with open(ruta_a, "rb") as f:
        _modelo_a = pickle.load(f)
    with open(ruta_b, "rb") as f:
        _modelo_b = pickle.load(f)
    with open(ruta_c, "rb") as f:
        _modelo_c = pickle.load(f)
    if os.path.exists(ruta_metricas):
        with open(ruta_metricas, "r", encoding="utf-8") as f:
            _metricas = json.load(f)
    log.info("Modelos A, B y C cargados desde %s/", CARPETA_MODELOS)


def _cargar_pipeline_emocion():
    global _pipeline_emocion
    if _pipeline_emocion is not None:
        return
    from transformers import pipeline
    log.info("Cargando modelo para perfil emocional (zero-shot, mDeBERTa-v3-mnli-xnli)...")
    _pipeline_emocion = pipeline(
        "zero-shot-classification",
        model="MoritzLaurer/mDeBERTa-v3-base-mnli-xnli",
    )


def _proba_clase_1(clf, X):
    clases = list(clf.classes_)
    idx = clases.index(1)
    return float(clf.predict_proba(X)[0][idx])


def clasificar_svm(texto: str) -> float:
    vect = _modelo_a["vectorizador"]
    clf = _modelo_a["clasificador"]
    X = vect.transform([texto])
    return _proba_clase_1(clf, X)


def clasificar_roberta(texto: str) -> float:
    emb = obtener_embeddings(MODELO_B_ROBERTA, [texto])
    return _proba_clase_1(_modelo_b["clasificador"], emb)


def clasificar_mdeberta(texto: str) -> float:
    emb = obtener_embeddings(MODELO_C_MDEBERTA, [texto])
    return _proba_clase_1(_modelo_c["clasificador"], emb)


def obtener_perfil_emocional(texto: str) -> List[str]:
    _cargar_pipeline_emocion()
    resultado = _pipeline_emocion(texto, candidate_labels=CATEGORIAS_EMOCIONALES, multi_label=True)
    return [et for et, sc in zip(resultado["labels"], resultado["scores"]) if sc >= UMBRAL_EMOCION]


def obtener_estilo(texto: str) -> str:
    _cargar_pipeline_emocion()
    resultado = _pipeline_emocion(texto, candidate_labels=[HIPOTESIS_ESTILO_EMOCIONAL, HIPOTESIS_ESTILO_LOGICO])
    return "emocional" if resultado["labels"][0] == HIPOTESIS_ESTILO_EMOCIONAL else "logico"


@app.post("/api/v1/clasificar", response_model=RespuestaClasificacion)
def clasificar(solicitud: SolicitudClasificacion):
    _cargar_modelos_entrenados()
    texto = solicitud.texto.strip()
    if not texto:
        raise HTTPException(status_code=400, detail="El campo 'texto' no puede estar vacio.")

    score_a = clasificar_svm(texto)
    score_b = clasificar_roberta(texto)
    score_c = clasificar_mdeberta(texto)

    confianza_final = (score_a + score_b + score_c) / 3.0
    es_verdadero = confianza_final >= UMBRAL_VERACIDAD

    perfil_emocional = obtener_perfil_emocional(texto) if es_verdadero else []
    estilo = obtener_estilo(texto) if es_verdadero else "logico"

    return RespuestaClasificacion(
        esVerdadero=es_verdadero,
        confianza=round(confianza_final, 3),
        perfilEmocional=perfil_emocional,
        estilo=estilo,
        detalleModelos={
            "A_TFIDF_SVM": round(score_a, 3),
            "B_RoBERTa_LogReg": round(score_b, 3),
            "C_mDeBERTa_v3_LogReg": round(score_c, 3),
        },
    )


@app.get("/metricas")
def metricas():
    """Devuelve el Accuracy y F1-Score (validacion cruzada 5-fold) de cada
    modelo, calculados por entrenar_modelos.py -- listos para citar en las
    tablas comparativas de las Practicas 2 y 3."""
    _cargar_modelos_entrenados()
    if _metricas is None:
        raise HTTPException(status_code=404, detail="No se encontro modelos_entrenados/metricas.json")
    return _metricas


@app.get("/salud")
def salud():
    return {"estado": "ok"}
