# dataset_semilla.py
#
# IMPORTANTE - LEER ANTES DE USAR EN LA TESIS:
# Este NO es el dataset real de 110 denuncias del piloto mencionado en la
# tesis (ese dataset nunca se armo). Es un conjunto semilla (bootstrap) de
# ejemplos escritos a mano, para poder entrenar y EVALUAR con metricas
# reales (accuracy, F1) los 3 modelos, mientras no exista un dataset real
# etiquetado por el equipo.
#
# Antes de la sustentacion, lo honesto es reemplazar o ampliar esto con
# relatos reales (anonimizados) recolectados en las pruebas de usabilidad
# con el Centro de Escucha o la Defensoria, y declarar en la tesis el
# tamano y origen real del dataset de entrenamiento.
#
# label = 1  -> relato especifico y creible (ejemplo de "verdadero")
# label = 0  -> mensaje vago, ruido, o sin detalle de un incidente real

EJEMPLOS = [
    # ---- Ejemplos positivos (relatos especificos y creibles) ----
    ("El martes pasado, en el pasillo del pabellón B, un compañero de clase me siguió y me amenazó diciendo que si contaba lo que vio me iría mal. Hay testigos cerca del aula 204.", 1),
    ("Desde hace tres semanas un estudiante del curso de redes me manda mensajes insistentes pidiéndome salir, y cuando le digo que no, me insulta frente a mis compañeros en el laboratorio.", 1),
    ("Mi compañero de prácticas me toma fotos sin mi permiso durante las clases de laboratorio y las comparte en un grupo de WhatsApp del salón.", 1),
    ("Un alumno del tercer semestre me ha estado esperando afuera de mi salón todos los lunes y miércoles desde hace un mes, y cuando le pedí que parara se puso agresivo verbalmente.", 1),
    ("En la última práctica de campo, un compañero mayor me tocó sin consentimiento mientras subíamos al bus; se lo comenté a otra compañera que también lo vio.", 1),
    ("Recibo mensajes de texto de un número desconocido con comentarios sobre mi cuerpo desde que publiqué una foto en el grupo de la facultad; empezó hace dos semanas.", 1),
    ("Un docente me pidió reunirme a solas fuera de horario de oficina en más de una ocasión y al negarme bajó mi nota sin justificación clara.", 1),
    ("Durante el trabajo en grupo, un compañero me gritó e insultó delante de todos porque no estuve de acuerdo con su propuesta, y luego me siguió hasta el estacionamiento.", 1),
    ("Hace dos días alguien dejó notas con comentarios ofensivos sobre mi orientación sexual pegadas en mi casillero; ya van tres veces que ocurre este semestre.", 1),
    ("Un compañero del taller de IA comparte capturas de mis mensajes privados en un chat grupal para burlarse, y ya me generó ansiedad para ir a clases.", 1),
    ("En la fiesta de bienvenida, un estudiante de ciclos superiores me acorraló en un pasillo y no me dejaba pasar hasta que otra persona intervino; desde entonces me busca en redes sociales.", 1),
    ("Mi ex pareja, que estudia en la misma facultad, le ha estado contando cosas falsas sobre mí a mis compañeros de salón y ahora varios me evitan; ya hablé con el delegado del salón sobre esto.", 1),
    ("Un grupo de compañeros creó un meme humillante sobre mi acento y lo comparten en el grupo de WhatsApp del curso desde la semana pasada; ya son más de diez mensajes.", 1),
    ("El encargado del laboratorio de redes me hace comentarios incómodos sobre mi apariencia cada vez que voy a pedir material, y ya evito ir cuando él está solo.", 1),
    ("Un compañero me pidió el número de celular con insistencia durante tres clases seguidas, y cuando me negué empezó a seguirme en Instagram con cuentas falsas.", 1),

    # ---- Ejemplos negativos (ruido, vago, no describe un incidente real) ----
    ("jajajaja xd", 0),
    ("hola", 0),
    ("no se", 0),
    ("solo probando el bot", 0),
    ("xdxdxd q tal", 0),
    ("nada, era broma", 0),
    ("alguien me molesta a veces", 0),
    ("todo mal en general no se ni por donde empezar jajaja", 0),
    ("esto es un test, ignorar", 0),
    ("hay gente mala en la u", 0),
    ("quiero reportar algo pero no se que", 0),
    ("asdasdasd asdasd", 0),
    ("buenas tardes", 0),
    ("ok gracias", 0),
    ("como funciona esto", 0),
    ("probando probando 123", 0),
    ("nada en especifico solo tenia curiosidad", 0),
    ("la universidad esta mal en general jaja", 0),
    ("xd ya fue, da igual", 0),
    ("emmmm no se bien que escribir aqui", 0),
]

TEXTOS = [t for t, _ in EJEMPLOS]
ETIQUETAS = [y for _, y in EJEMPLOS]
