# embeddings.py
#
# Extrae embeddings (vectores numericos) de un texto usando RoBERTa o
# mDeBERTa-v3 ya entrenados, SIN modificar sus pesos (modelos congelados).
# Esto es distinto del zero-shot: aqui el modelo grande solo "lee" el texto
# y lo convierte en un vector; quien aprende a distinguir "relato real" de
# "ruido" es un clasificador chico (LogisticRegression) entrenado encima de
# esos vectores, con el dataset semilla.
#
# Modelos usados (version base, multilingues, sin fine-tuning de terceros
# para NLI -- aqui se usan tal cual, como extractores de caracteristicas):
#   B. xlm-roberta-base         (familia RoBERTa)
#   C. microsoft/mdeberta-v3-base (familia DeBERTa-v3, igual a la tesis)

import numpy as np

# NOTA: torch y transformers se importan DENTRO de las funciones (import
# diferido) y no aqui arriba, a proposito: asi el resto del proyecto
# (dataset_semilla.py, la logica de evaluacion con validacion cruzada,
# etc.) se puede probar e importar incluso en una maquina donde todavia
# no se instalaron esas librerias pesadas (varios cientos de MB).

_modelos_cache = {}


def _cargar(nombre_modelo: str):
    import torch  # noqa: F401 (se usa mas abajo via el modelo)
    from transformers import AutoTokenizer, AutoModel

    if nombre_modelo not in _modelos_cache:
        tokenizer = AutoTokenizer.from_pretrained(nombre_modelo)
        modelo = AutoModel.from_pretrained(nombre_modelo)
        modelo.eval()
        _modelos_cache[nombre_modelo] = (tokenizer, modelo)
    return _modelos_cache[nombre_modelo]


def _mean_pooling(salida_modelo, attention_mask):
    import torch
    tokens_embeddings = salida_modelo.last_hidden_state  # (batch, seq_len, hidden)
    mask = attention_mask.unsqueeze(-1).expand(tokens_embeddings.size()).float()
    suma = torch.sum(tokens_embeddings * mask, dim=1)
    conteo = torch.clamp(mask.sum(dim=1), min=1e-9)
    return suma / conteo


def obtener_embeddings(nombre_modelo: str, textos: list) -> np.ndarray:
    """Devuelve un array (n_textos, hidden_size) con el embedding promedio
    de cada texto, usando el modelo dado SIN entrenarlo (solo inferencia)."""
    import torch
    tokenizer, modelo = _cargar(nombre_modelo)
    salidas = []
    tam_lote = 8
    with torch.no_grad():
        for i in range(0, len(textos), tam_lote):
            lote = textos[i:i + tam_lote]
            entradas = tokenizer(lote, padding=True, truncation=True, max_length=256, return_tensors="pt")
            salida = modelo(**entradas)
            emb = _mean_pooling(salida, entradas["attention_mask"])
            salidas.append(emb.numpy())
    return np.vstack(salidas)


MODELO_B_ROBERTA = "xlm-roberta-base"
MODELO_C_MDEBERTA = "microsoft/mdeberta-v3-base"
