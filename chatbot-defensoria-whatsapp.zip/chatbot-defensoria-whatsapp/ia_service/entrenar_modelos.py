# entrenar_modelos.py
#
# Entrena y EVALUA con validacion cruzada (5-fold) los 3 modelos sobre el
# dataset semilla, e imprime una tabla de Accuracy y F1-Score por modelo --
# lista para copiar a las tablas comparativas de las Practicas 2 y 3.
#
# Tambien guarda en disco (carpeta modelos_entrenados/) los 3 modelos ya
# entrenados con el dataset COMPLETO, listos para que ia_service.py los
# cargue sin tener que reentrenar en cada arranque.
#
# Correr:
#   python entrenar_modelos.py

import json
import os
import pickle

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import accuracy_score, f1_score

from dataset_semilla import TEXTOS, ETIQUETAS
from embeddings import obtener_embeddings, MODELO_B_ROBERTA, MODELO_C_MDEBERTA

CARPETA_SALIDA = "modelos_entrenados"
N_SPLITS = 5


def evaluar_tfidf_svm(textos, etiquetas):
    skf = StratifiedKFold(n_splits=N_SPLITS, shuffle=True, random_state=42)
    accs, f1s = [], []
    textos = np.array(textos)
    etiquetas = np.array(etiquetas)
    for train_idx, test_idx in skf.split(textos, etiquetas):
        vect = TfidfVectorizer(ngram_range=(1, 2), min_df=1)
        X_train = vect.fit_transform(textos[train_idx])
        X_test = vect.transform(textos[test_idx])
        clf = SVC(kernel="linear", probability=True, class_weight="balanced")
        clf.fit(X_train, etiquetas[train_idx])
        pred = clf.predict(X_test)
        accs.append(accuracy_score(etiquetas[test_idx], pred))
        f1s.append(f1_score(etiquetas[test_idx], pred, zero_division=0))
    return float(np.mean(accs)), float(np.mean(f1s))


def evaluar_embeddings_logreg(embeddings, etiquetas):
    skf = StratifiedKFold(n_splits=N_SPLITS, shuffle=True, random_state=42)
    accs, f1s = [], []
    etiquetas = np.array(etiquetas)
    for train_idx, test_idx in skf.split(embeddings, etiquetas):
        clf = LogisticRegression(max_iter=1000, class_weight="balanced")
        clf.fit(embeddings[train_idx], etiquetas[train_idx])
        pred = clf.predict(embeddings[test_idx])
        accs.append(accuracy_score(etiquetas[test_idx], pred))
        f1s.append(f1_score(etiquetas[test_idx], pred, zero_division=0))
    return float(np.mean(accs)), float(np.mean(f1s))


def main():
    os.makedirs(CARPETA_SALIDA, exist_ok=True)
    resultados = {}

    print(f"Dataset semilla: {len(TEXTOS)} ejemplos ({sum(ETIQUETAS)} positivos, {len(ETIQUETAS)-sum(ETIQUETAS)} negativos)")
    print(f"Evaluando con validacion cruzada de {N_SPLITS} particiones...\n")

    # ---- Modelo A: TF-IDF + SVM ----
    print("Modelo A (TF-IDF + SVM)...")
    acc_a, f1_a = evaluar_tfidf_svm(TEXTOS, ETIQUETAS)
    resultados["A_TFIDF_SVM"] = {"accuracy": acc_a, "f1_score": f1_a}

    vect_final = TfidfVectorizer(ngram_range=(1, 2), min_df=1)
    X_final = vect_final.fit_transform(TEXTOS)
    clf_a_final = SVC(kernel="linear", probability=True, class_weight="balanced")
    clf_a_final.fit(X_final, ETIQUETAS)
    with open(f"{CARPETA_SALIDA}/modelo_a.pkl", "wb") as f:
        pickle.dump({"vectorizador": vect_final, "clasificador": clf_a_final}, f)

    # ---- Modelo B: RoBERTa (embeddings congelados) + LogisticRegression ----
    print("Modelo B (RoBERTa + LogisticRegression)... (descarga el modelo la primera vez)")
    emb_b = obtener_embeddings(MODELO_B_ROBERTA, TEXTOS)
    acc_b, f1_b = evaluar_embeddings_logreg(emb_b, ETIQUETAS)
    resultados["B_RoBERTa_LogReg"] = {"accuracy": acc_b, "f1_score": f1_b}

    clf_b_final = LogisticRegression(max_iter=1000, class_weight="balanced")
    clf_b_final.fit(emb_b, ETIQUETAS)
    with open(f"{CARPETA_SALIDA}/modelo_b.pkl", "wb") as f:
        pickle.dump({"clasificador": clf_b_final}, f)

    # ---- Modelo C: mDeBERTa-v3 (embeddings congelados) + LogisticRegression ----
    print("Modelo C (mDeBERTa-v3 + LogisticRegression)... (descarga el modelo la primera vez)")
    emb_c = obtener_embeddings(MODELO_C_MDEBERTA, TEXTOS)
    acc_c, f1_c = evaluar_embeddings_logreg(emb_c, ETIQUETAS)
    resultados["C_mDeBERTa_v3_LogReg"] = {"accuracy": acc_c, "f1_score": f1_c}

    clf_c_final = LogisticRegression(max_iter=1000, class_weight="balanced")
    clf_c_final.fit(emb_c, ETIQUETAS)
    with open(f"{CARPETA_SALIDA}/modelo_c.pkl", "wb") as f:
        pickle.dump({"clasificador": clf_c_final}, f)

    with open(f"{CARPETA_SALIDA}/metricas.json", "w", encoding="utf-8") as f:
        json.dump(resultados, f, indent=2, ensure_ascii=False)

    print("\n" + "=" * 60)
    print(f"{'Modelo':<28}{'Accuracy':>12}{'F1-Score':>12}")
    print("-" * 60)
    for nombre, m in resultados.items():
        print(f"{nombre:<28}{m['accuracy']*100:>11.1f}%{m['f1_score']:>12.3f}")
    print("=" * 60)
    print(f"\nModelos y metricas guardados en ./{CARPETA_SALIDA}/")
    print("NOTA: evaluados con el dataset semilla (bootstrap), no con el piloto real de 110 denuncias.")


if __name__ == "__main__":
    main()
