# Servicio de Clasificación IA — los 3 modelos de la tesis (con métricas reales)

Este microservicio implementa los **3 modelos reales** mencionados en la tesis, usando embeddings congelados + un clasificador chico encima (Opción 2), de forma que **los 3 tienen Accuracy y F1-Score reales y comparables**, no solo un puntaje de "qué tan verdadero suena".

| Modelo | Cómo funciona | ¿Se entrena algo? |
|---|---|---|
| A. TF-IDF + SVM | Vectoriza el texto por frecuencia de palabras y entrena un SVM | Sí, completo |
| B. RoBERTa (`xlm-roberta-base`) | RoBERTa convierte el texto en un vector (embedding), **sin reentrenarse**; encima se entrena una Regresión Logística | Solo la Regresión Logística |
| C. mDeBERTa-v3 (`microsoft/mdeberta-v3-base`) | Igual que B, pero con mDeBERTa-v3 — la misma familia que la tesis reportó como la de mejor desempeño | Solo la Regresión Logística |

El resultado final de veracidad es el **promedio de los 3 puntajes**.

El perfil emocional (28 categorías) y el estilo narrativo siguen usando
**zero-shot** (un mDeBERTa-v3 ya afinado para NLI por terceros), porque no
existe un dataset de emociones etiquetado para entrenar eso de forma
supervisada — igual que la tesis describe para esa parte específica.

## ⚠️ Léeme antes de poner esto en la tesis

El dataset de `dataset_semilla.py` (35 ejemplos) **no es el dataset real del
piloto de 110 denuncias** que menciona la tesis — es un conjunto bootstrap
que escribí para poder entrenar y evaluar con métricas reales mientras no
exista un dataset real etiquetado por el equipo. Las métricas que salen de
`entrenar_modelos.py` son honestas (de verdad se calculan con validación
cruzada), pero están calculadas sobre ese dataset bootstrap, no sobre datos
reales de denuncias. Si van a defender esto ante el jurado, lo correcto es
decir exactamente eso. Más adelante pueden reemplazar o ampliar el dataset
con relatos reales anonimizados y volver a correr `entrenar_modelos.py` —
las métricas se recalculan solas.

## Cómo correrlo (necesitas internet normal — esto no corre en el sandbox de Claude)

```bash
cd ia_service
pip install -r requirements.txt

# Paso 1: entrenar y evaluar los 3 modelos (una sola vez; la primera vez
# descarga xlm-roberta-base y mdeberta-v3-base desde Hugging Face, pesan
# varios cientos de MB cada uno)
python entrenar_modelos.py

# Esto imprime una tabla como esta (numeros reales, de verdad calculados):
#
#   Modelo                     Accuracy    F1-Score
#   ------------------------------------------------
#   A_TFIDF_SVM                   94.3%       0.943
#   B_RoBERTa_LogReg              ...%        ...
#   C_mDeBERTa_v3_LogReg          ...%        ...
#
# y guarda los modelos entrenados en modelos_entrenados/

# Paso 2: levantar el servicio
uvicorn ia_service:app --host 0.0.0.0 --port 8000
```

### En Google Colab (recomendado — tiene GPU gratis, va más rápido)

1. Sube toda la carpeta `ia_service/` a Colab (o móntala desde Drive).
2. ```python
   !pip install -r requirements.txt -q
   !python entrenar_modelos.py
   ```
3. Para exponerlo con una URL pública (Colab no tiene IP fija):
   ```python
   !pip install pyngrok -q
   from pyngrok import ngrok
   import subprocess, time

   subprocess.Popen(["uvicorn", "ia_service:app", "--host", "0.0.0.0", "--port", "8000"])
   time.sleep(5)
   print(ngrok.connect(8000))
   ```
4. Copia la URL impresa y úsala al arrancar el bot de WhatsApp:
   ```bash
   CLASSIFIER_API_URL=https://xxxx.ngrok-free.app/api/v1/clasificar node index.js
   ```
   (la URL de ngrok gratis cambia cada vez que reinicias el Colab)

## Endpoints

- `POST /api/v1/clasificar` — clasifica un relato (mismo contrato que ya usa el bot).
- `GET /metricas` — devuelve el Accuracy y F1-Score de cada modelo (calculados por `entrenar_modelos.py`), listos para copiar a las tablas comparativas de las Prácticas 2 y 3.
- `GET /salud` — chequeo simple de que el servicio está vivo.

## Probarlo directo, sin el bot

```bash
curl -X POST http://localhost:8000/api/v1/clasificar \
  -H "Content-Type: application/json" \
  -d '{"texto": "Un compañero me ha estado siguiendo después de clases desde hace dos semanas y me manda mensajes amenazantes."}'
```

La respuesta incluye `detalleModelos` con el puntaje de cada uno de los 3
modelos por separado — útil para mostrar en la sustentación que efectivamente
los 3 están participando, no solo el que "gana".
