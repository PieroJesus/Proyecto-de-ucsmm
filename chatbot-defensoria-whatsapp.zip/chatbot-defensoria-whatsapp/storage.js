// storage.js
//
// Implementa dos de los componentes de la arquitectura (Practica 5):
//   1. "Almacen de Consentimiento y Estado Local" -> archivo consents.json
//   2. "Adaptador de Base de Datos de la Defensoria" -> archivo defensoria_db.json
//
// IMPORTANTE (RNF01 - seguridad/anonimato):
// El identificador de WhatsApp (chatId) SOLO se usa, hasheado (SHA-256),
// para registrar el consentimiento (RF10). Nunca se guarda junto con el
// contenido de una denuncia ni junto con el ID de caso. El ID de caso es
// un UUID aleatorio sin relacion matematica con el numero de telefono.
//
// En produccion real, "guardarEnDefensoria" y "consultarEstado" deberian
// llamar a la API que la OTI habilite sobre la base de datos real de la
// Defensoria Universitaria (ver Practica 5, "Adaptador de Base de Datos
// de la Defensoria"), en vez de escribir en un archivo JSON local.

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const DATA_DIR = path.join(__dirname, "data");
const CONSENTS_FILE = path.join(DATA_DIR, "consents.json");
const DEFENSORIA_DB_FILE = path.join(DATA_DIR, "defensoria_db.json");
const REVISION_MANUAL_FILE = path.join(DATA_DIR, "revision_manual.json");

function ensureDataFiles() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  for (const f of [CONSENTS_FILE, DEFENSORIA_DB_FILE, REVISION_MANUAL_FILE]) {
    if (!fs.existsSync(f)) fs.writeFileSync(f, "[]", "utf-8");
  }
}

function readJson(file) {
  ensureDataFiles();
  return JSON.parse(fs.readFileSync(file, "utf-8"));
}
function writeJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2), "utf-8");
}

function hashChatId(chatId) {
  return crypto.createHash("sha256").update(String(chatId)).digest("hex");
}

// ---------- RF10: consentimiento informado ----------
function tieneConsentimiento(chatId) {
  const hash = hashChatId(chatId);
  const consents = readJson(CONSENTS_FILE);
  return consents.some((c) => c.hash === hash);
}

function registrarConsentimiento(chatId) {
  const hash = hashChatId(chatId);
  const consents = readJson(CONSENTS_FILE);
  if (!consents.some((c) => c.hash === hash)) {
    consents.push({ hash, fecha: new Date().toISOString() });
    writeJson(CONSENTS_FILE, consents);
  }
}

// ---------- RF06: identificador de caso anonimo ----------
function generarIdCaso() {
  // Formato corto y facil de dictar/escribir: DEF-XXXXXX
  return "DEF-" + crypto.randomBytes(4).toString("hex").toUpperCase();
}

// ---------- RF07 / RF11: guardar reporte verificado ----------
function guardarEnDefensoria({ idCaso, relato, veracidad, perfilEmocional, estilo }) {
  const db = readJson(DEFENSORIA_DB_FILE);
  db.push({
    idCaso,
    relato,
    veracidad,
    perfilEmocional,
    estilo,
    estado: "Recibido",
    fecha: new Date().toISOString(),
    // NOTA: no se guarda aqui ningun dato que identifique al remitente.
  });
  writeJson(DEFENSORIA_DB_FILE, db);
}

// Casos que no superaron el umbral de veracidad (flujo alternativo UC01)
function guardarParaRevisionManual({ idCaso, relato, veracidad, perfilEmocional }) {
  const rev = readJson(REVISION_MANUAL_FILE);
  rev.push({
    idCaso,
    relato,
    veracidad,
    perfilEmocional,
    estado: "En revision manual",
    fecha: new Date().toISOString(),
  });
  writeJson(REVISION_MANUAL_FILE, rev);
}

// ---------- RF09: consulta de estado ----------
function consultarEstado(idCaso) {
  const db = readJson(DEFENSORIA_DB_FILE);
  const enDb = db.find((c) => c.idCaso === idCaso);
  if (enDb) return enDb.estado;

  const rev = readJson(REVISION_MANUAL_FILE);
  const enRev = rev.find((c) => c.idCaso === idCaso);
  if (enRev) return enRev.estado;

  return null;
}

module.exports = {
  tieneConsentimiento,
  registrarConsentimiento,
  generarIdCaso,
  guardarEnDefensoria,
  guardarParaRevisionManual,
  consultarEstado,
};
