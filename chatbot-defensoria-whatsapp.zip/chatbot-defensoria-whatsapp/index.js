// index.js
//
// Chatbot conversacional con IA, integrado en WhatsApp, para dar a conocer
// la Defensoria Universitaria de la UCSM y recibir denuncias anonimas de
// acoso. Implementa el "Gestor de Conversacion" y el "Gestor de Casos" de
// la arquitectura documentada en la Practica 5.
//
// Uso:
//   1) npm install
//   2) node index.js
//   3) Escanear el codigo QR que aparece en la terminal con WhatsApp
//      (en el telefono: Ajustes > Dispositivos vinculados > Vincular un dispositivo)
//
// Comandos que entiende el bot (sin menus, solo texto libre, ver RF02-RF04):
//   "hola" / "start"            -> bienvenida (RF01)
//   "defensoria" / "que es..."  -> informacion institucional (RF02)
//   "denunciar"                 -> inicia el flujo de denuncia (RF03, RF04, RF10)
//   "listo"                     -> cierra el relato y dispara la clasificacion (RF05)
//   "estado DEF-XXXXXXXX"       -> consulta el seguimiento de un caso (RF09)

const { Client, LocalAuth } = require("whatsapp-web.js");
const qrcode = require("qrcode-terminal");

const storage = require("./storage");
const { clasificar, UMBRAL_VERACIDAD } = require("./classifier");

const client = new Client({
  authStrategy: new LocalAuth(),
  puppeteer: {
    args: ["--no-sandbox", "--disable-setuid-sandbox"],
  },
});

// Estado de conversacion en memoria, por chat (solo mientras el proceso corre).
// No se persiste en disco: ver storage.js para lo que SI se guarda.
const estados = new Map();
function getEstado(chatId) {
  if (!estados.has(chatId)) estados.set(chatId, { etapa: "idle", buffer: [], reintentos: 0 });
  return estados.get(chatId);
}

const MENSAJE_BIENVENIDA =
  "Hola, soy el asistente de la *Defensoría Universitaria de la UCSM*. 🛡️\n\n" +
  "La Defensoría Universitaria existe para proteger tus derechos como estudiante, " +
  "incluyendo situaciones de acoso dentro o fuera del campus.\n\n" +
  "Puedes escribirme en cualquier momento:\n" +
  "• *denunciar* — para reportar una situación de acoso de forma anónima\n" +
  "• *¿qué es la Defensoría Universitaria?* — para más información\n" +
  "• *estado DEF-XXXXXXXX* — para ver el avance de un caso ya reportado";

const MENSAJE_INFO_DEFENSORIA =
  "La *Defensoría Universitaria* es un órgano autónomo de la UCSM (Ley Universitaria N.° 30220) " +
  "encargado de proteger los derechos de los estudiantes y de recibir, gestionar y dar seguimiento " +
  "a casos de acoso y otras situaciones que afecten tu bienestar.\n\n" +
  "Si quieres reportar algo, escribe *denunciar*. Si prefieres hablar con alguien primero, " +
  "el Centro de Escucha y Consejería Psicológica UCSM también puede ayudarte.";

const MENSAJE_CONSENTIMIENTO =
  "Antes de continuar: tu relato se analizará con un modelo de IA y, si se clasifica como verídico, " +
  "se guardará de forma *anónima* (sin vincularlo a este número de WhatsApp) en la base de datos de " +
  "la Defensoría Universitaria, conforme a la Ley N.° 29733 de Protección de Datos Personales.\n\n" +
  "Responde *acepto* para continuar, o escribe cualquier otra cosa para cancelar.";

function esperandoDenuncia() {
  return (
    "Te escucho. Cuéntame con tus propias palabras qué pasó — puedes escribir uno o varios mensajes.\n" +
    "Cuando termines, escribe *listo*."
  );
}

function esSaludoOInicio(t) {
  return ["hola", "start", "/start", "buenas", "buenos dias", "buenos días"].includes(t);
}
function esPreguntaDefensoria(t) {
  return t.includes("defensoria") || t.includes("defensoría");
}
function esComandoDenunciar(t) {
  return t === "denunciar" || t === "/denunciar";
}
function esComandoListo(t) {
  return t === "listo" || t === "/listo";
}
function esComandoEstado(t) {
  return t.startsWith("estado");
}

async function manejarMensaje(msg) {
  const chatId = msg.from;
  const textoOriginal = (msg.body || "").trim();
  const t = textoOriginal.toLowerCase();
  const estado = getEstado(chatId);

  // --- Consultar estado de un caso (RF09), disponible en cualquier momento ---
  if (esComandoEstado(t)) {
    const idCaso = textoOriginal.split(/\s+/)[1];
    if (!idCaso) {
      await msg.reply("Escribe el identificador junto al comando, por ejemplo: estado DEF-AB12CD34");
      return;
    }
    const estadoCaso = storage.consultarEstado(idCaso.toUpperCase());
    if (estadoCaso) {
      await msg.reply(`El caso *${idCaso.toUpperCase()}* figura como: *${estadoCaso}*.`);
    } else {
      await msg.reply("No encontré ningún caso con ese identificador. Verifica que esté bien escrito.");
    }
    return;
  }

  // --- Flujo de denuncia en curso ---
  if (estado.etapa === "awaiting_consent") {
    if (t === "acepto") {
      storage.registrarConsentimiento(chatId); // RF10
      estado.etapa = "collecting";
      estado.buffer = [];
      estado.reintentos = 0;
      await msg.reply(esperandoDenuncia());
    } else {
      estado.etapa = "idle";
      await msg.reply("De acuerdo, no se inició ninguna denuncia. Escribe *denunciar* cuando quieras intentarlo.");
    }
    return;
  }

  if (estado.etapa === "collecting") {
    if (esComandoListo(t)) {
      const relato = estado.buffer.join("\n").trim();
      if (!relato) {
        await msg.reply("Todavía no recibí ningún mensaje con tu relato. Cuéntame qué pasó, o escribe *listo* solo cuando hayas escrito algo.");
        return;
      }

      const resultado = await clasificar(relato); // RF05

      if (resultado.esVerdadero) {
        const idCaso = storage.generarIdCaso(); // RF06
        storage.guardarEnDefensoria({
          idCaso,
          relato,
          veracidad: resultado.confianza,
          perfilEmocional: resultado.perfilEmocional,
          estilo: resultado.estilo,
        }); // RF07 / RF11

        let respuesta =
          `Gracias por confiar en este canal. Tu reporte quedó registrado con el identificador *${idCaso}*.\n` +
          `Puedes usarlo más adelante escribiendo: estado ${idCaso}`;

        // RF08: ofrecer recursos si hay alta carga emocional
        if (resultado.perfilEmocional && resultado.perfilEmocional.length > 0) {
          respuesta +=
            "\n\nSi quieres hablar con alguien, el *Centro de Escucha y Consejería Psicológica UCSM* " +
            "está disponible para apoyarte. No estás solo/a en esto.";
        }

        await msg.reply(respuesta);
        estado.etapa = "idle";
        estado.buffer = [];
        estado.reintentos = 0;
      } else if (estado.reintentos < 1) {
        // Flujo alternativo UC01 (8a): pedir más detalle una vez
        estado.reintentos += 1;
        await msg.reply(
          "Quiero entender mejor lo que pasó para poder ayudarte: ¿puedes contarme con un poco más de " +
          "detalle (qué ocurrió, cuándo, dónde)? Cuando termines, escribe *listo* otra vez."
        );
        // el buffer se mantiene, se seguirá acumulando
      } else {
        // Flujo alternativo UC01 (8b): no se remite a la Defensoría, queda para revisión manual
        const idCaso = storage.generarIdCaso();
        storage.guardarParaRevisionManual({
          idCaso,
          relato,
          veracidad: resultado.confianza,
          perfilEmocional: resultado.perfilEmocional,
        });
        await msg.reply(
          "Gracias por tu paciencia. Tu mensaje quedó guardado de forma anónima para que una persona lo revise " +
          `manualmente. Tu identificador es *${idCaso}* — puedes consultarlo con: estado ${idCaso}`
        );
        estado.etapa = "idle";
        estado.buffer = [];
        estado.reintentos = 0;
      }
      return;
    }

    // Cualquier otro mensaje mientras se está "escuchando" se agrega al relato (RF04)
    estado.buffer.push(textoOriginal);
    return; // sin respuesta por cada mensaje, para que se sienta como escribir un chat normal
  }

  // --- Estado inicial / conversacion libre ---
  if (esSaludoOInicio(t)) {
    await msg.reply(MENSAJE_BIENVENIDA); // RF01
    return;
  }

  if (esComandoDenunciar(t)) {
    if (storage.tieneConsentimiento(chatId)) {
      estado.etapa = "collecting";
      estado.buffer = [];
      estado.reintentos = 0;
      await msg.reply(esperandoDenuncia());
    } else {
      estado.etapa = "awaiting_consent";
      await msg.reply(MENSAJE_CONSENTIMIENTO); // RF10
    }
    return;
  }

  if (esPreguntaDefensoria(t)) {
    await msg.reply(MENSAJE_INFO_DEFENSORIA); // RF02
    return;
  }

  // Mensaje no reconocido fuera de un flujo activo
  await msg.reply(
    "No estoy seguro de haber entendido. Puedes escribir *denunciar*, preguntarme *¿qué es la Defensoría Universitaria?*, " +
    "o escribir *estado DEF-XXXXXXXX* si ya tienes un caso."
  );
}

client.on("qr", (qr) => {
  console.log("Escanea este codigo QR con WhatsApp (Dispositivos vinculados):");
  qrcode.generate(qr, { small: true });
});

client.on("ready", () => {
  console.log("Bot de la Defensoria Universitaria listo y conectado a WhatsApp.");
});

// Marca invisible (espacio de ancho cero) que se antepone a TODAS las respuestas
// del bot. Sirve para que el bot reconozca sus propios mensajes y no se responda
// a si mismo en bucle cuando se prueba escribiendose en el chat "Tu".
const MARCA_BOT = "\u200B";

function envolverRespuestas(msg) {
  const replyOriginal = msg.reply.bind(msg);
  msg.reply = (texto, ...resto) => replyOriginal(MARCA_BOT + texto, ...resto);
  return msg;
}

function debeProcesar(msg) {
  if (msg.body && msg.body.startsWith(MARCA_BOT)) return false; // es una respuesta del propio bot
  if (!msg.fromMe) return true;                                  // mensaje normal de otra persona
  return msg.from === msg.to;                                    // mensaje mio: solo si es el chat conmigo mismo (modo prueba)
}

client.on("message_create", (msg) => {
  if (!debeProcesar(msg)) return;
  manejarMensaje(envolverRespuestas(msg)).catch((err) => {
    console.error("Error manejando mensaje:", err);
  });
});

client.initialize();
